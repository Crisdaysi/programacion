#include <stdio.h>
#include <stdlib.h>

void listaCandidaturas(void);
void menuCandidaturas(void);
void muestraCandidaturas(void);
void gestionMenuCandidaturas(void);

void listadoCandidaturas();
void muestralistaCandidatuas();
