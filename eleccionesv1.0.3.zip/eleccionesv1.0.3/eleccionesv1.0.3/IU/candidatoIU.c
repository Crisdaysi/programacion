#include <stdio.h>
#include <stdlib.h>
#include "candidatoIU.h"
#include "interfazUsuario.h"
#include "interfazGrafica.h"

void listadoCandidatos(){{
}
void muestralistaCandidatos(){
}


int menuCandidatos()
{
    int elegir;

    gotoxy(4,2);
    printf(" Gestiones para Candidatos");

    gotoxy(2,8);
    printf( "1. Listado de candidatos.");

    gotoxy(2,9);
    printf( "2. Tramitar alta para nuevo candidato.");

    gotoxy(2,10);
    printf( "3. Fin de la gestion.");

    gotoxy(16,24);
    printf("Selecciona una opcion: ");
    scanf("%d", &elegir);


    return elegir;
}


void gestionMenuCandidatos()
{
    int elegir;


    elegir = menuCandidatos();

    while(elegir !=0)
    {
        switch(elegir)
        {
        case 1:
            leeDatosCandidatos();
            break;
        case 2:
            altaCandidatoIU();
            break;
        default:
            gotoxy(16,24);
            printf("Opcion no valida.\n");
        }
        elegir = menuCandidatos();
    }

}


void altaCandidatoIU()
{
    int edad;
    char nom[15];
    char siglas[15];


    gotoxy(16,25);
    printf("Introduce siglas de candidatura:");
    scanf("%s", siglas);

    gotoxy(2,8);
    printf("siglas candidatura: %s", siglas);


    gotoxy(16,25);
    getchar();
    printf("Nombre y Apellido del candidato:");
    gets(nom);

    gotoxy(2,9);
    printf("Nombre del candidato: %s", nom);


    gotoxy(16,26);
    printf("Edad del candidato:");
    scanf("%d",&edad);


    gotoxy(2,10);
    printf("Edad: %d",edad);

    altaCandidatoSYS(siglas,nom,edad);

}


/*void muestraCandidato(char siglas[30],int edad,char nombre[30])
{
    gotoxy(16,28);
    printf("%s   %d   %s", siglas,edad,nombre);

}*/
