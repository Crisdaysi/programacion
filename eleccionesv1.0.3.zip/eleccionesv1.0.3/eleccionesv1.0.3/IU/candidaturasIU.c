#include <stdio.h>
#include <stdlib.h>
#include "interfazGrafica.h"
#include "interfazUsuario.h"


void listadoCandidaturas(){
}

void muestralistaCandidatuas(){
}

int menuCandidaturas()
{
    int elegir;


    gotoxy(2,7);
    printf( "1. Listado de candidaturas.");
    gotoxy(2,8);
    printf( "2. Fin de la gestion.");
    gotoxy(20,25);

    printf("Selecciona una opcion: ");
    scanf("%d", &elegir);


    return elegir;
}

void gestionMenuCandidaturas()
{
    int elegir;


    gotoxy(4,2);
    printf(" Gestion de Candidaturas");

    elegir = menuCandidaturas();

    while(elegir !=0 )
    {
        switch(elegir)
        {
        case 1:
             listaCandidaturas();
            break;
        default:
            printf("Opcion no valida.\n");
        }
        elegir = menuCandidaturas();
    }

}

void listaCandidaturas()
{
    FILE *fpp;
    char siglas[50];
    char nombre[100];
    int j;
    j = 7;

    fpp = fopen("BaseDatos/candidaturas.txt","rt");
    gotoxy(64,4);
    printf("candidatura:\tnombre:");
    while(fscanf(fpp, "%s", siglas)==1)
    {
        _fgets(nombre, 100, fpp);
        gotoxy(64,j);
        muestraCandidaturas(siglas,nombre);
        j++;
    }
    fclose(fpp);
    gotoxy(22,25);
    getchar();
    printf("Pulsa <INTRO> para continuar...");
    getchar();

    return;
}
void muestraCandidaturas(char siglas[10],char nombre[30])
{
    printf("%s \t \t%s", siglas,nombre);
}
