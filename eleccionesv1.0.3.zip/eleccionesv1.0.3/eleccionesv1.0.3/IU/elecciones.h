void muestraResultadoEleccines();
void muestraListavotos();
