/* Archivo de cabecera con los prototipos
   del archivo interfazGrafica.c */
#include <windows.h>

enum graficos1
{
    ESIZQ=218, ESDER=191, LHOR=196, EIIZQ= 192,
    EIDER= 217, TDER = 195, TIZQ = 180
};

void rectangulo(int x, int y, int ancho, int alto, char pincel, char lienzo);
void setColorTexto(char pincel, char lienzo);
void gotoxy(int x, int y);
void modoTexto();
void modoGrafico();
char* _fgets(char *candidato, int n, FILE *ptr);
