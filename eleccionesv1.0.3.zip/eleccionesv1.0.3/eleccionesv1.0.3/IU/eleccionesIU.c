#include <stdio.h>
#include <stdlib.h>
#include "interfazUsuario.h"
#include "interfazGrafica.h"

void muestraResultadoEleccines(){
}
void muestraListavotos(){
}
