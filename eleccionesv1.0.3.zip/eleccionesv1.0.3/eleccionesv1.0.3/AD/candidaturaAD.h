
void cargaListaCandidaturasAD();
