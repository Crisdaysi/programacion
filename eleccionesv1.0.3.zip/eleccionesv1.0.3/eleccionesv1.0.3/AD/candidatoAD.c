#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "candidatoAD.h"
#include "../IU/candidatoIU.h"
#include "../IU/interfazGrafica.h"
#include "../IU/interfazUsuario.h"

void cargaListaCandidatosAD(){
}


bool altaCandidatoAD(char candidatura[30], int edad, char nombre[30])
{   /*agrega los datos del nuevo condidato al archivo con el mismo formato los almacena*/

    FILE *pld;
    pld = fopen("BaseDatos/candidatos.txt","at");
    fprintf(pld,"%s \t%d\t%s\n",candidatura,edad,nombre);

    if (pld == NULL)
    {
        return false;
    }
    fclose(pld);
    return true;
}


void leeDatosCandidatos()
{
    FILE *prm;
    int r;
    int edad;
    char siglas[30];
    char nombre[90];

    r = 7;
    prm = fopen("BaseDatos/candidatos.txt","rt");
    gotoxy(64,4);
    printf("Candidatura:\t  Edad:\t Nombre:");

    while(fscanf(prm, "%c %d", siglas,&edad)==2)
    {
        _fgets(nombre, 100, prm);
        gotoxy(64,r);
        muestraCandidato (siglas, edad, nombre);
        r++;
        if (r==22)
        {
            getchar();
            r=7;
            getchar();
        }

    }
    getchar();
    gotoxy(22,28);
    printf("Pulsa <INTRO> para continuar...");
    getchar();

    fclose(prm);
    return;
}





