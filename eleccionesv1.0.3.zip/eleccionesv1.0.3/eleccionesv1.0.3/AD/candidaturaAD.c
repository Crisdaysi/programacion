void cargaListaCandidaturasAD(){
}

