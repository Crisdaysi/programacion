#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
void leeDatosCandidatos(void);
bool altaCandidatoAD(char candidatura[30], int edad, char nombre[30]);
void muestraCandidato(char siglas[30],int edad,char nombre[30]);

void cargaListaCandidatosAD();
