

void altaCandidatoSYS(char candidatura[20], int edad, char nombre[25], char msg[30]);
