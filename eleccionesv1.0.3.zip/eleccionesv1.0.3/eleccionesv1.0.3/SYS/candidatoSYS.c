#include <stdio.h>
#include <stdlib.h>
#include "candidatoSYS.h"
#include "../AD/candidatoAD.h"
#include "../IU/candidatoIU.h"
#include "../IU/interfazGrafica.h"
#include "../IU/interfazUsuario.h"

void altaCandidatoSYS(char candidatura[20], int edad, char nombre[25], char msg[30])

{       /*comprobar los datos de los candidatos de funciones IU y AD*/

    msg[30] = altaCandidatoAD(candidatura,edad,nombre);

    if (msg == false)
    {
        gotoxy(18,25);
        printf( "No se puede abrir el archivo.");
    }
    else
    {

        gotoxy(18,25);
        getchar();
        printf( "Candidato %s dado de alta con exito.(pulse intro para continuar)", nombre);
        getchar();
    }
}


