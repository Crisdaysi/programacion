void escrutinio();
void genVotaciones();
void maximoVotos();
void simElecciones();

