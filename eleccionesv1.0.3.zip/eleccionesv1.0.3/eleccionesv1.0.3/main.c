#include <stdio.h>
#include "IU/interfazGrafica.h"
#include "IU/interfazUsuario.h"


int main(){

    system("title SIMULADOR DE ELECCIONES");
    system("mode con cols=100 lines=35");

     inicInterfazUsuario();
     menuPrincipal();
    gestionMenuPrincipal();



return 0;
}
