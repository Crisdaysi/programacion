#include <stdio.h>
#include <stdlib.h>
int menuPrincipal();
void  inicInterfazUsuario(void);
void gestionMenuprincipal();
void rellenaRectangulo(int x, int y, int ancho, int alto);
void rectangulo(int x, int y, int ancho, int alto, char pincel, char lienzo);
void setColorTexto(char pincel, char lienzo);
void gotoxy(int x, int y);

//listo
