#include <stdio.h>
#include <stdlib.h>
#include "candidatoIU.h"
#include "interfazUsuario.h"
#include "interfazGrafica.h"
//#include candidatoAD
//#include  altacandiSYS

//menu
int menuCandidatos()
{
    int elegir;

    rectangulo(1,1,39,2,13,0);
    gotoxy(4,2);
    printf(" Gestiones para Candidatos");

    rectangulo(44,1,39,2,13,0);

    gotoxy(2,8);
    printf( "1. Listado de candidatos.");

    gotoxy(2,9);
    printf( "2. Tramitar alta para nuevo candidato.");

    gotoxy(2,10);
    printf( "3. Fin de la gestion.");

    gotoxy(16,24);
    printf("Selecciona una opcion: ");
    scanf("%d", &elegir);


    return elegir;
}


void gestionMenuCandidatos()
{
    int elegir;

    ///rectangulos nuevos
    elegir = menuCandidatos();

    while(elegir !=0)
    {
        switch(elegir)
        {
        case 1:
            leeDatosCandidatos();
            break;
        case 2:
            altaCandidatoIU();
            break;
        default:
            gotoxy(16,24);
            printf("Opcion no valida.\n");
        }
        elegir = menuCandidatos();
    }

}


void altaCandidatoIU()
{
    int edad;
    char nom[15];
    char siglas[15];

    //retcangulo nuevo del mismo tama�o
    gotoxy(16,25);
    printf("Introduce siglas de candidatura:"); //entrada de datos
    scanf("%s", siglas);

    gotoxy(2,8); //ract grande
    printf("siglas candidatura: %s", siglas);


    gotoxy(16,25); //entrada
    getchar();
    printf("Nombre y Apellido del candidato:");
    gets(nom);

    gotoxy(2,9); ///arriba
    printf("Nombre del candidato: %s", nom);


    gotoxy(16,26);      ///entrada
    printf("Edad del candidato:");
    scanf("%d",&edad);
     ///arriba

    gotoxy(2,10);
    printf("Edad: %d",edad);

    altaCandidatoSYS(siglas,nom,edad);

}




void muestraCandidato(char siglas[30],int edad,char nombre[30])
{
    gotoxy(16,28);
    printf("%s \t  %d \t %s", siglas,edad,nombre);
}
