#include <stdio.h>
#include <stdlib.h>
void altaCandidatoIU(void);
void gestionMenuCandidatos(void);
int menuCandidatos();
void muestraCandidato(char siglas[30],int edad,char nombre[30]);




