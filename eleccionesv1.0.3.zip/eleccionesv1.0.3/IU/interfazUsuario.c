#include <stdio.h>
#include"interfazUsuario.h"
#include "interfazGrafica.h"
#include "candidatoIU.h"
#include "../AD/candidatoAD.h"
#include "../SYS/candidatoSYS.h"
#include "candidaturasIU.h"


void inicInterfazUsuario(){

    setColorTexto( 13, 0);

    // rectangulo(int x, int y, int ancho, int alto, char pincel, char lienzo);

    rectangulo(1,1,39,2,13,0);
    gotoxy(5,2);
    printf("GESTOR DE CANDIDATURAS \n     Menu principal");

    rectangulo(44,1,39,2,13,0);

    rectangulo(1,6,39,15,13,0);
    rectangulo(44,6,39,15,13,0);

    rectangulo(1,23,10,2,13,0);

    gotoxy(2,25);
    printf("Entrada");

    rectangulo(1,27,10,2,13,0);
    gotoxy(2,28);
    printf("Mensajes");

    rectangulo(15,23,68,2,13,0);
    rectangulo(15,27,68,2,13,0);


return;
}


int menuPrincipal()
{
    int elegir;

    gotoxy(2,8);
    printf( "1. Gestion de candidatos.");
    gotoxy(2,9);
    printf( "2. Gestion de Candidaturas.");
    gotoxy(2,10);
    printf( "3. Fin del Programa.");
    gotoxy(2,11);

    gotoxy(16,24);
    printf("Selecciona una opcion: ");
    scanf("%d", &elegir);

    return elegir;
}

void  gestionMenuPrincipal()
{

    int usuelegir;

    usuelegir = menuPrincipal();

    while(usuelegir !=0 )
    {
        switch(usuelegir)
        {
        case 1:
             gestionMenuCandidatos();
            break;
        case 2:
             gestionMenuCandidaturas();
            break;
        case 3:
               printf("Fin del programa ");
            break;
        default:
            printf("Esta opcion no es valida.");
        }
        usuelegir = menuPrincipal();
    }
}



















